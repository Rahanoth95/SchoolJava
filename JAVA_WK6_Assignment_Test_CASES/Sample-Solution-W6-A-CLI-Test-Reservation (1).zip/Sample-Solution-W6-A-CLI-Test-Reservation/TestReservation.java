/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author omora
 */

import java.util.*;
import java.text.SimpleDateFormat;

public class TestReservation {
    
    private static String datePattern = "MMM dd, yyyy";
    private static SimpleDateFormat sdf = new SimpleDateFormat(datePattern);
                  
    public static void main(String argv[]) throws Exception {
        testConstructorAndGetters();
        testSettersAndGetters();
        testCalculateReservationNumberOfDays();
        testCalculateReservationBillAmount();
    }
    
    public static void testConstructorAndGetters() {
        System.out.println();
        System.out.println("Teting Constructor and Getters");
        System.out.println("-------------------------------");
        Reservation r = new Reservation(1, "RoomWBath", "Jun 16, 2022", "Jun 19, 2022");
        Reservation r2 = new Reservation(7, "RoomWBath", "Jun 16, 2022", "Jun 19, 2022");
        Assert.assertNotEqualsUUID(r.getReservationID(), r2.getReservationID());
        Assert.assertEqualsDate(r.getReservationDate(), new Date() );
        Assert.assertEqualsString(sdf.format(r.getReservationDate()), sdf.format(new Date()) );
        Assert.assertEqualsInt(r.getGuestID(), 1);
        Assert.assertEqualsString(r.getRoomType(), "RoomWBath");
        Assert.assertEqualsString(r.getReservationStartDate(), "Jun 16, 2022");
        Assert.assertEqualsString(r.getReservationEndDate(), "Jun 19, 2022");
    }
    
    
    public static void testSettersAndGetters() {
        System.out.println();
        System.out.println("Teting Setters and Getters");
        System.out.println("-------------------------------");
        Reservation r = new Reservation(7, "NormalRoom", "Jan 07, 2023", "Jan 17, 2023");
        r.setGuestID(77);
        Assert.assertEqualsInt(r.getGuestID(), 77);
        r.setRoom("RoomWView");
        Assert.assertEqualsString(r.getRoomType(), "RoomWView");
        r.setReservationStartDate("Jan 10, 2023");
        Assert.assertEqualsString(r.getReservationStartDate(), "Jan 10, 2023");
        r.setReservationEndDate("Jan 15, 2023");
        Assert.assertEqualsString(r.getReservationEndDate(), "Jan 15, 2023");
    }
    
    
    
    public static void testCalculateReservationNumberOfDays() throws Exception {
        System.out.println();
        System.out.println("Teting calculateReservationNumberOfDays()");
        System.out.println("-------------------------------");
        Reservation r = new Reservation(1, "RoomWBath", "Jun 12, 2022", "Jun 14, 2022");
        Assert.assertEqualsLong(r.calculateReversationNumberOfDays(), 2L);    
        Reservation r2 = new Reservation(11, "NormalRoom", "Dec 27, 2020", "Jan 04, 2021");
        Assert.assertEqualsLong(r2.calculateReversationNumberOfDays(), 8L); 
        Reservation r3 = new Reservation(34, "NormalRoom", "Feb 27, 2022", "Mar 02, 2022");
        Assert.assertEqualsLong(r3.calculateReversationNumberOfDays(), 3L); 
        Reservation r4 = new Reservation(99, "RoomWBath", "Jul 27, 2024", "Jul 28, 2024");
        Assert.assertEqualsLong(r4.calculateReversationNumberOfDays(), 1L); 
    }
    
    public static void testCalculateReservationBillAmount() throws Exception{
        System.out.println();
        System.out.println("Teting calculateReservationBillAmount()");
        System.out.println("-------------------------------");
        Reservation r = new Reservation(1, "RoomWBath", "Jun 12, 2022", "Jun 14, 2022");
        Assert.assertEqualsDouble(r.calculateReservationBillAmount(), 400);   
        Reservation r2 = new Reservation(5, "RoomWView", "Mar 21, 2024", "Mar 26, 2024");
        Assert.assertEqualsDouble(r2.calculateReservationBillAmount(), 875);  
        Reservation r3 = new Reservation(67, "NormalRoom", "Sep 01, 2023", "Sep 05, 2023");
        Assert.assertEqualsDouble(r3.calculateReservationBillAmount(), 500);  
    }
    
}
