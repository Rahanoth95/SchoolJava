// CMSC 330 Advanced Programming Languages
// Project 1 Skeleton
// UMGC CITE
// Spring 2023
// Johnathan Brandstetter
// Date 2/4/2023 = 2/7/2023

// Enumerated type that defines the list of tokens

enum Token {AT, COLOR, END,	HEIGHT, RECTANGLE, RIGHT_TRIANGLE, ISOSCELES_TRIANGLE, REGULAR_POLYGON, TEXT, PARALLELOGRAM,
    SCENE, WIDTH, COMMA, SEMICOLON, PERIOD, LEFT_PAREN, RADIUS, SIDES, OFFSET,
    RIGHT_PAREN, IDENTIFIER, NUMBER, EOF}